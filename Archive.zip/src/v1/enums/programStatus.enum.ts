export enum ProgramStatus {
    PROPOSED = "Proposed",
    ONGOING = "Ongoing",
    COMPLETED = "Completed",
}
