export enum DatabaseType {
  postgres = 'postgres',
  mongo = 'mongodb',
  mysql = 'mysql',
}
