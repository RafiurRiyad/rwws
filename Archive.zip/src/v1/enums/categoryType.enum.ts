export enum CategoryType {
    NEWS = "news",
    STORY = "story",
    PROGRAM = "program",
}
