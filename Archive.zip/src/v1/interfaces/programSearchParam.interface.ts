export interface ProgramSearchParam {
    page?: number;
    pageSize?: number;
    categoryId?: number;
    status?: string;
}
