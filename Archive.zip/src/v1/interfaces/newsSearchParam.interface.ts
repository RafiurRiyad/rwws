export interface NewsSearchParam {
    page?: number;
    pageSize?: number;
    categoryId?: number;
    year?: string;
}
