export interface HttpResponsePayload {
  message: string;
  data?: any;
}
