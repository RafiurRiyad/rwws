export interface StorySearchParam {
    page?: number;
    pageSize?: number;
    categoryId?: number;
    location?: string;
}
