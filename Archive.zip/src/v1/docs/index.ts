import basicInfo from "./basicInfo";

export const docs = {
  ...basicInfo,
};
