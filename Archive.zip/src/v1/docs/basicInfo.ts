export = {
  openapi: '3.0.0',
  info: {
    version: '1.0.0',
    title: 'toffee-admin-service',
    description: 'toffee admin service',
    license: 'Toffee',
    contact: {
      name: 'Toffee',
      url: 'https://toffeelive.com/',
    },
  },
};
