import { parsedEnvironment } from './environment.processor';
export const environment = parsedEnvironment;
