import { authController } from "./auth.controller";

export const AuthController = authController;
